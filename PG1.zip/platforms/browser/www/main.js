var app = angular.module('app', ['ngRoute', 'highcharts-ng', 'ngTable']);
